#Author: Harish Polishetti
#block2
def math_op():
    try:
        try:
            inp_b = int(input("Enter your first number here:"))#enter your 1st integer value
            inp_c = int(input("Enter your second number here:"))#enter your 2nd integer value
        except ValueError:
            print ("Please enter only number not strings")
            return None
        if type(inp_b) == int and type(inp_c) == int:
            addition = inp_b + inp_c  #addition operator
            subtraction = inp_b - inp_c #subtraction operator
            multiplication = inp_b * inp_c #multiplication operator
            if inp_c != 0:
                division = inp_b/inp_c #division operator
            else:
                division = None
                print("division by zero is not possible")
            print(addition,subtraction,multiplication,division)
        else:
            print("please enter a valid number")
    except Exception as error:
        print("Error occured {}".format(error))
#end of block2

if __name__ == "__main__":
    math_op()